import Layout, { siteTitle } from '../components/layout';
import { useRouter } from 'next/router';

import Head from 'next/head';
import Script from 'next/script';

export default function Escola() {

    const router = useRouter();
    const { municipio, escola } = router.query;

  return (
    <Layout>

      <Head>
        <title>{siteTitle}</title>
        <link rel="icon" href="/cm.png" />
      </Head>

      <main >
        

        <div>Escola em {municipio}: {escola} </div>

      </main>

    </Layout>
  )
}

