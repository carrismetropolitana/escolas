
export default function Teste() {
    return <p>teste</p>;
  }