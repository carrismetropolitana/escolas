import '../styles/global.css';
import 'select2';
import 'jquery';
import 'select2/dist/css/select2.min.css';

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />;
}